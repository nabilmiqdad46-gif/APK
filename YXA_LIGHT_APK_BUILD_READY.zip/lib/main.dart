import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(const YxaLightApp());

class YxaLightApp extends StatelessWidget {
  const YxaLightApp({super.key});

  @override
  Widget build(BuildContext context) {
    const blue = Color(0xFF287BFF);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'YXA LIGHT',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF080D18),
        colorScheme: ColorScheme.fromSeed(
          seedColor: blue,
          brightness: Brightness.dark,
          surface: const Color(0xFF111A2B),
        ),
        useMaterial3: true,
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF111A2B),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFF263550)),
          ),
        ),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  // Set these in lib/config.dart or replace the placeholders below.
  // Supabase URL and anon key are public client values; never put a service-role key here.
  static const supabaseUrl = 'https://YOUR_PROJECT.supabase.co';
  static const supabaseAnonKey = 'YOUR_SUPABASE_ANON_KEY';
  static const adminPhone = '6281996872623';

  final targetController = TextEditingController();
  final noteController = TextEditingController();
  String requestType = 'Permintaan bantuan';
  bool sending = false;
  String status = '';
  final List<String> history = [];

  final requestTypes = const [
    'Permintaan bantuan',
    'Laporan kendala aplikasi',
    'Permintaan akses',
    'Pertanyaan fitur',
    'Laporan lainnya',
  ];

  @override
  void dispose() {
    targetController.dispose();
    noteController.dispose();
    super.dispose();
  }

  bool get configured =>
      !supabaseUrl.contains('YOUR_PROJECT') &&
      !supabaseAnonKey.contains('YOUR_SUPABASE_ANON_KEY');

  Future<void> submitRequest() async {
    final target = targetController.text.trim();
    final note = noteController.text.trim();
    if (target.isEmpty || note.isEmpty) {
      setState(() => status = 'Isi target/akun dan keterangan terlebih dahulu.');
      return;
    }

    setState(() {
      sending = true;
      status = '';
    });

    final createdAt = DateTime.now().toUtc().toIso8601String();
    final payload = {
      'request_type': requestType,
      'target': target,
      'message': note,
      'created_at': createdAt,
      'status': 'baru',
      'app_name': 'YXA LIGHT',
    };

    try {
      if (!configured) {
        setState(() => status =
            'Server belum disetel. Ikuti README_SETUP.txt untuk menghubungkan Supabase.');
        return;
      }

      final response = await http.post(
        Uri.parse('$supabaseUrl/rest/v1/admin_requests'),
        headers: {
          'apikey': supabaseAnonKey,
          'Authorization': 'Bearer $supabaseAnonKey',
          'Content-Type': 'application/json',
          'Prefer': 'return=minimal',
        },
        body: jsonEncode(payload),
      );

      if (response.statusCode == 201 || response.statusCode == 204) {
        if (!mounted) return;
        setState(() {
          history.insert(0, '$requestType • $target • terkirim ke server');
          status = 'Laporan tersimpan di server. Admin dapat melihatnya di dashboard Supabase.';
        });
        await openWhatsApp(payload);
      } else {
        setState(() => status =
            'Gagal menyimpan laporan (HTTP ${response.statusCode}). Periksa tabel dan policy Supabase.');
      }
    } catch (e) {
      setState(() => status = 'Tidak dapat terhubung ke server. Periksa internet dan konfigurasi.');
    } finally {
      if (mounted) setState(() => sending = false);
    }
  }

  Future<void> openWhatsApp(Map<String, dynamic> payload) async {
    final text = Uri.encodeComponent(
      'YXA LIGHT — Laporan baru\\n'
      'Jenis: ${payload['request_type']}\\n'
      'Target/akun: ${payload['target']}\\n'
      'Keterangan: ${payload['message']}\\n'
      'Waktu UTC: ${payload['created_at']}\\n'
      'Catatan: laporan bantuan aplikasi.',
    );
    final uri = Uri.parse('https://wa.me/$adminPhone?text=$text');
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [
          Icon(Icons.bolt_rounded, color: Color(0xFF4B91FF)),
          SizedBox(width: 8),
          Text('YXA LIGHT', style: TextStyle(fontWeight: FontWeight.w800)),
        ]),
        actions: [
          IconButton(
            tooltip: 'Info',
            icon: const Icon(Icons.info_outline),
            onPressed: () => showAboutDialog(
              context: context,
              applicationName: 'YXA LIGHT',
              applicationVersion: '1.0.0',
              children: const [
                Text('Aplikasi untuk mengirim permintaan bantuan dan laporan kendala ke admin.'),
              ],
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(22),
                gradient: const LinearGradient(
                  colors: [Color(0xFF173E83), Color(0xFF101A30)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                border: Border.all(color: const Color(0xFF2D65B8)),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('CONTROL CENTER', style: TextStyle(color: Color(0xFF9FC4FF), letterSpacing: 2, fontSize: 11)),
                  SizedBox(height: 10),
                  Text('Admin Request Portal', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800)),
                  SizedBox(height: 8),
                  Text('Kirim laporan melalui server dan lanjutkan ke WhatsApp admin.'),
                ],
              ),
            ),
            const SizedBox(height: 22),
            const Text('BUAT LAPORAN', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.2)),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: requestType,
              decoration: const InputDecoration(labelText: 'Jenis permintaan'),
              items: requestTypes.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
              onChanged: (v) => setState(() => requestType = v ?? requestType),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: targetController,
              decoration: const InputDecoration(
                labelText: 'Target / nama akun',
                hintText: 'Masukkan nama akun atau ID yang relevan',
                prefixIcon: Icon(Icons.person_outline),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: noteController,
              minLines: 3,
              maxLines: 5,
              decoration: const InputDecoration(
                labelText: 'Keterangan',
                hintText: 'Jelaskan kendala atau permintaan Anda',
                prefixIcon: Icon(Icons.edit_note_rounded),
                alignLabelWithHint: true,
              ),
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: sending ? null : submitRequest,
              icon: sending
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.send_rounded),
              label: Text(sending ? 'MENGIRIM...' : 'KIRIM KE ADMIN'),
              style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)),
            ),
            if (status.isNotEmpty) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFF111A2B),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFF2D65B8)),
                ),
                child: Text(status),
              ),
            ],
            const SizedBox(height: 24),
            const Text('RIWAYAT PENGIRIMAN', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.2)),
            const SizedBox(height: 10),
            if (history.isEmpty)
              const Text('Belum ada laporan terkirim dari sesi ini.', style: TextStyle(color: Colors.white60))
            else
              ...history.map((item) => Card(
                    child: ListTile(
                      leading: const Icon(Icons.check_circle_outline, color: Color(0xFF4B91FF)),
                      title: Text(item),
                    ),
                  )),
            const SizedBox(height: 20),
            const Text(
              'Catatan: laporan masuk ke server setelah Supabase dikonfigurasi. WhatsApp terbuka dengan pesan siap kirim; pengguna tetap perlu menekan tombol Kirim di WhatsApp.',
              style: TextStyle(color: Colors.white54, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}
